# uzb_flag
Uzbekistan Flag
