import platform
import psutil

print("System Information\n")
uname = platform.uname()
ram = str(round(psutil.virtual_memory().total / (1024.0 **3)))+" GB"

print(f"System: {uname.system}")
print(f"Node Name: {uname.node}")
print(f"Release: {uname.release}")
print(f"Version: {uname.version}")
print(f"Machine: {uname.machine}")
print(f"Processor: {uname.processor}")
print(f"RAM: {ram}")
