# >> pip install colorama
# >> pip install termcolor
from termcolor import colored
from colorama import init
init()

'''
Ranglar -
  grey
  red
  green
  yellow
  blue
  magenta
  cyan
  white
'''
background = "red"
text_color = "white"

text = colored('Hello, World!', text_color, "on_"+background)
print(text)

input() # Pause programm
