# Face detector
import numpy as np
import cv2

face_cascade = cv2.CascadeClassifier('haarcascade_frontalface_default.xml')

# Rasmni olish
file = '<input image>'
image = cv2.imread(file)
gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
faces = face_cascade.detectMultiScale(gray, 1.3, 5)

# Yuzni aniqlash
for (x,y,w,h) in faces:
    cv2.rectangle(image, (x,y), (x+w,y+h), (127,0,255), 2)
    print(True)
    cv2.waitKey(0)

# Natija 'result.jpg' faylida saqlanadi
cv2.imwrite('<output image>', image)
cv2.destroyAllWindows()
