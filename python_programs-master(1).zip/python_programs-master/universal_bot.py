#1.Admin
#2.Kanal
#3.Boom, Bomba
#4.Yangi yilga qancha qoldi
#5.Vaqt
#6.COVID19
#7.Tasodifiy raqam tanlash
import telebot
import datetime
from time import strftime
from covid import Covid
from random import randint

bot = telebot.TeleBot("<API-TOKEN>")
keyboard = telebot.types.ReplyKeyboardMarkup(True, True)
keyboard.row('😎Admin😎', '📡Kanal📡')
keyboard.row('🎇Boom, Bomba🎆')
keyboard.row('❄️Yangi yilga qancha qoldi☃️')
keyboard.row('⏳Vaqt⌛️', '😷Covid 19🤒')
keyboard.row('🎰Tasodifiy raqam tanlash🎲')

@bot.message_handler(commands=['start'])
def start_message(message):
    bot.send_message(message.chat.id, 'Main', reply_markup=keyboard)

@bot.message_handler(content_types=['text'])
def send_text(message):
    #======================
    if message.text == '😎Admin😎':
        bot.send_message(message.chat.id, "Ushbu bot dasturchisi: @junior_coder_2007")
    #======================
    if message.text == '📡Kanal📡':
        bot.send_message(message.chat.id, "https://t.me/python_dasturlash_darslari")
        bot.send_message(message.chat.id, "https://t.me/joinchat/AAAAAEMEdHI9_qdPEkxcTg")
    #======================
    if message.text == '🎇Boom, Bomba🎆':
        for num in range(51):
            bot.send_message(message.chat.id, "Boooom "+str(num))
    #======================
    if message.text == '❄️Yangi yilga qancha qoldi☃️':
        today = datetime.date.today()
        futdate = datetime.date(int(today.year), 12, 31)
        now = datetime.datetime.now()
        mnight = now.replace(hour=0, minute=0, second=0, microsecond=0)
        seconds = (mnight - now).seconds
        days = (futdate - today).days
        hms = str(datetime.timedelta(seconds=seconds)).split(':')
        hms = str(int(hms[0])-5)+':'+hms[1]+':'+hms[2]
        bot.send_message(message.chat.id, ("Yangi Yilga\n%d kun, %s qoldi" % (days, hms)))
    #======================
    if message.text == '⏳Vaqt⌛️':
        tt=str(strftime("%H:%M:%S")).split(':')
        tt[0]=int(tt[0])+5
        t=str(tt[0])+':'+str(tt[1])+':'+str(tt[2])
        bot.send_message(message.chat.id, 'Sana: '+str(datetime.date.today())+'\n'+'Soat: '+t)
    #======================
    if message.text == '😷Covid 19🤒":' or "O'zbekistonda" or 'Dunyoda' or 'Bosh menyuga qaytish':
        covid_kb = telebot.types.ReplyKeyboardMarkup(True, True)
        covid_kb.row("O'zbekistonda", "Dunyoda")
        covid_kb.row("Bosh menyuga qaytish")
        if message.text == "😷Covid 19🤒":
            bot.send_message(message.chat.id, "Siz Covid 19 bo'limidasiz", reply_markup=covid_kb)
        elif message.text == "O'zbekistonda":
            covid = Covid()
            uz = covid.get_status_by_country_name("Uzbekistan")
            y=str(uz['recovered']).replace(',','')
            s=str(uz['confirmed']).replace(',','')
            v=str(uz['deaths']).replace(',','')
            r = "Yuqtirganlar: "+s+'\n'+"Sog‘ayganlar: "+y+'\n'+"Vafot etganlar: "+v
            bot.send_message(message.chat.id, r, reply_markup=covid_kb)
        elif message.text == "Dunyoda":
            Covid19 = Covid()
            active = Covid19.get_total_active_cases()
            deaths = Covid19.get_total_deaths()
            confirmed = Covid19.get_total_confirmed_cases()
            bot.send_message(message.chat.id, "Yuqtirganlar: "+str(active)+'\n'+"Vafot etganlar: "+str(deaths)+'\n'+"Sog'ayganlar: "+str(confirmed), reply_markup=covid_kb)
        elif message.text == "Bosh menyuga qaytish":
            bot.send_message(message.chat.id, 'Main', reply_markup=keyboard)
    #======================
    if message.text == '🎰Tasodifiy raqam tanlash🎲':
        bot.send_message(message.chat.id, '🎲'+str(randint(0, 10))+'🎲')
    #======================

if __name__ == '__main__':
    bot.polling(none_stop=True)
