# python_programs
Python dasturlar
