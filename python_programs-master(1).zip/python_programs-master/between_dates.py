import datetime
now = datetime.datetime.now()
now = datetime.date(now.year, now.month, now.day)

future_year = 2021
future_month = 12
future_day = 31
future_date = datetime.date(future_year, future_month, future_day)

delta = now - future_date
res = abs(delta.days)
print(f"{future_day}.{future_month}.{future_year} gacha {res} kun bor")
