from math import gcd
x, a = 34,35
y, b = 33,34
z, c = 2,7
def EKUK(num_list):
    lcm = 1
    for num in num_list:
        lcm = lcm*num//gcd(lcm, num)
    return lcm

def EKUB(a,b):
  while b:
    a,b = b, a%b
  return a

k = EKUK([a, b])
x = int(k/a*x)
y = int(k/b*y)
#z = int(k/c*z)

print(f"{x}/{k}; {y}/{k}")
