# comment-of-image
Python, Flask app: send &amp; read comment 
