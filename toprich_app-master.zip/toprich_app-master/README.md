# toprich_app
TOP rich persons in the W.O.R.L.D - App (JS)
