# online-shop_simple-landing
Online do'kon uchun Landing Page<br>
- https://online-shop-landing.netlify.app/
