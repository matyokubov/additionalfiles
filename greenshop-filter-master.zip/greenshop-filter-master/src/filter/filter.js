const list = [
    {
        title: "All Plants",
        statusName: "all"
    },
    {
        title: "New Arrivals",
        statusName: "new"
    },
    {
        title: "Sale",
        statusName: "sale"
    }
];

export default list;