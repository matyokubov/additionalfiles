const list = [
    {
        title: "House Plants",
        categoryName: "plants"
    },
    {
        title: "Seeds",
        categoryName: "seeds"
    },
    {
        title: "Gardening",
        categoryName: "gardening"
    }
];

export default list;