# Tenglama Bot

## Tenglamalarni yechuvchi Telegram bot

Ishlatish uchun kutubxonalar -
- `pip install pyTelegramBotAPI`
- `pip install sympy`
