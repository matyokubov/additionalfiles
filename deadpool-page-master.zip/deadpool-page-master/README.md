# deadpool-page
Deadpool uchun Landing Page<br>
- https://deadpool-page.netlify.app/
