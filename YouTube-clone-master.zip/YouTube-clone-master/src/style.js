import styled from "styled-components";

export const Container = styled.div`
    display: flex;
`;

export const Wrapper = styled.div`
    width: 100%;
`;