# svetafor
JavaScript da yasagan Svetafor dasturim
